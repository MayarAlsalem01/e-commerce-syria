import React from 'react'
import Container from '@/components/ui/Container'


import { Sidebar, SidebarContent, SidebarGroup, SidebarHeader, SidebarInset, SidebarProvider, SidebarTrigger } from '@/components/ui/sidebar'
import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectValue } from '@/components/ui/select'
import { SelectTrigger } from '@radix-ui/react-select'
import ProductList from '@/features/product/components/ProductList'
import { baseUrl, endpoints } from '@/lib/httpClient'
import { QueryClient } from '@tanstack/react-query'
import { productKeys } from '@/lib/queryKeys'
import { ResponseResult } from '@/types/ResponseResult'
import { Product } from '@/features/product/types/product'

export default async function Page() {
    const res = await fetch(`${baseUrl}${endpoints.products}?page=1&per_page=10`, {
        method: 'GET',

    })
    if (!res.ok) {
        throw new Error('sad')
    }
    const data = await res.json() as ResponseResult<Product[]>
    console.log(data)
    data.data
    const queryClinet = new QueryClient()
    queryClinet.setQueryData([productKeys.all, { "page": 1, "per_page": 10 }], data.data)
    console.log(res)
    return (
        <section>
            <SidebarProvider className=''>
                <Sidebar variant='inset'>
                    <div className='bg-secondary/70 rounded-2xl w-full h-[85vh] top-20 relative py-2'>
                        <SidebarHeader>
                            <p className=''>Filters:</p>

                        </SidebarHeader>
                        <SidebarContent>
                            <SidebarGroup>
                                {/* <ProductPriceRangeSilder /> */}
                                <Select >

                                    <SelectTrigger className='border border-primary/80 rounded-lg outline-0 text-sm' >

                                        <SelectValue placeholder="Select a Category" />
                                    </SelectTrigger>
                                    <SelectContent className='bg-background'>
                                        <SelectGroup >
                                            <SelectItem value="apple" className=''>Apple</SelectItem>
                                            <SelectItem value="banana">Banana</SelectItem>
                                            <SelectItem value="blueberry">Blueberry</SelectItem>
                                            <SelectItem value="grapes">Grapes</SelectItem>
                                            <SelectItem value="pineapple">Pineapple</SelectItem>
                                        </SelectGroup>
                                    </SelectContent>
                                </Select>
                            </SidebarGroup>
                        </SidebarContent>

                    </div>
                </Sidebar>
                <Container >
                    <SidebarInset className='bg-background top-2'>
                        <SidebarTrigger />
                        <ProductList />
                    </SidebarInset>

                </Container>
            </SidebarProvider>
        </section>
    )
}
