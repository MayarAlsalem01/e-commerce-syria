// hooks/useHttpClient.js
'use client';

import { useEffect, useMemo } from 'react';
import { useLocale } from 'next-intl';
import { httpClient } from '@/lib/httpClient';

/**
 * A hook to configure the httpClient with the current locale from next-intl.
 * This should be used in any Client Component that initiates API calls.
 * @returns The configured httpClient instance.
 */
export function useHttpClient() {
    // Get the current locale from next-intl
    const locale = useLocale();

    // Use useMemo to ensure the interceptor is only set up once per locale change
    const client = useMemo(() => {
        // Create a new instance to avoid modifying the global 'httpClient'
        // which could affect other components if not handled carefully.
        const instance = httpClient.create();

        // 2. Add a request interceptor to set the header
        const interceptor = instance.interceptors.request.use(
            (config: any) => {
                // Set the Accept-Language header using the current locale
                config.headers['Accept-Language'] = locale;
                return config;
            },
            (error: any) => {
                return Promise.reject(error);
            }
        );

        // Cleanup function to remove the interceptor when the component unmounts
        // or the locale changes, preventing memory leaks or duplicate headers.
        return () => {
            instance.interceptors.request.eject(interceptor);
        };
    }, [locale]);

    // Cleanup the interceptor when the component unmounts
    useEffect(() => {
        return client;
    }, [client]);

    return httpClient; // Return the base instance, which is now configured
}
