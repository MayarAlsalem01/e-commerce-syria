import { endpoints, httpClient } from '@/lib/httpClient'
import { useQuery } from '@tanstack/react-query'
import { Product } from '../types/product'
import { productKeys } from '@/lib/queryKeys'

export default function useFetchProductById(productId: string) {
    return useQuery({
        queryKey: productKeys.id(productId),
        queryFn: async () => {
            const res = await httpClient.get(endpoints.productById + '/' + productId)
            return res.data.data as Product
        }
    })
}
